
package veterinaria;

import java.sql.SQLException;

public class MenuDatos {
    
    public static void main(String args [] ) throws SQLException {
        
       Cliente c1 = new Cliente (2,"juan",32);
        Mascotas m1 = new Mascotas("kevin",789456413);

        Conector cn = new Conector();
        cn.insert(c1, m1); 
       
    }
    }
    

